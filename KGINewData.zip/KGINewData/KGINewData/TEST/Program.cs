﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Threading.Tasks;
using KGI.Net.Mail;
using Utility;

namespace TEST
{
    class Program
    {
        static DataTable etnBasicData;
        static void Main(string[] args)
        {
            //SendMail.SendMailer();
            string sqlquery = "SELECT * FROM [ETF基本資料表]";
            etnBasicData = SQL.CMoney.ExecCMoneyQry(sqlquery);
            CSVUtlity.SaveToCSV(etnBasicData, $".\\TEST2_CSV.csv");
            Console.ReadLine();
        }

    }



    public class SendMail
    {
        public static void SendMailer()
        {
            try
            {
                string updatTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                KGIMailMessage ms = new KGIMailMessage();
                ms.From = "licheng@kgi.com";
                string mailTo = "licheng@kgi.com";
                ms.Subject = " [測試信件3] ";
                ms.Body = "測試信件內文";
                ms.Send(ms.From, mailTo, null, null, ms.Body, ms.Subject);
                Console.WriteLine("郵件寄送完成");
                Console.ReadLine();
                //MailService ms = new MailService();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                Console.ReadLine();
            }
        }
        
    }

}
