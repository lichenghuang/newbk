﻿using System;
using System.Net;
using System.Net.Mail;

namespace KGI.Net.Mail
{
    public class KGIMailMessage
    {
        private MailMessage m_mailMessage = null;
        private SmtpClient m_smtpClient = null;
        private string m_smtp;
        private string m_attachment;
        private string m_from;
        private string m_to;
        private string m_cc;
        private string m_subject;
        private string m_body;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param KGIMailMessage="smtp_server">SMTP SERVER</param>
        public KGIMailMessage()
        {
            string smtp_server = "dzmail01.kgi.com";
            this.m_mailMessage = new MailMessage();
            this.m_smtpClient = new SmtpClient(smtp_server);
            this.m_mailMessage.BodyEncoding = System.Text.Encoding.GetEncoding("big5");
        }



        /// <summary>
        /// 寄件人
        /// </summary>
        public string From
        {
            get
            {
                return this.m_from;
            }
            set
            {
                if (string.IsNullOrEmpty(value) == false)
                {
                    this.m_from = value;

                    MailAddress from = new MailAddress(this.m_from);
                    this.m_mailMessage.From = from;
                }
            }
        }
        /// <summary>
        /// 收件人
        /// </summary>
        public string To
        {
            set
            {
                this.m_mailMessage.To.Clear();
                if (string.IsNullOrEmpty(value) == false)
                {
                    this.m_to = value;

                    string[] arr = value.Split(';');
                    foreach (string str in arr)
                    {
                        MailAddress to = new MailAddress(str);
                        this.m_mailMessage.To.Add(to);
                    }
                }
            }
        }
        /// <summary>
        /// CC
        /// </summary>
        public string CC
        {
            set
            {
                if (string.IsNullOrEmpty(value) == false)
                {
                    this.m_cc = value;
                    MailAddress cc = new MailAddress(this.m_cc);
                    this.m_mailMessage.CC.Add(cc);
                }
            }
        }
        /// <summary>
        /// 內文
        /// </summary>
        public string Body
        {
            get
            {
                return this.m_body;
            }
            set
            {
                this.m_body = value;
                this.m_mailMessage.Body = this.m_body;
            }
        }
        /// <summary>
        /// 主旨
        /// </summary>
        public string Subject
        {
            get
            {
                return this.m_subject;
            }
            set
            {
                this.m_subject = value;
                this.m_mailMessage.Subject = this.m_subject;
            }
        }
        /// <summary>
        /// 附件
        /// </summary>
        public string Attachment
        {
            set
            {
                this.m_attachment = value;
                Attachment data = new Attachment(this.m_attachment);
                this.m_mailMessage.Attachments.Add(data);
            }
        }
        public MailMessage MailMessage
        {
            get
            {
                return this.m_mailMessage;
            }
        }
        public bool UseDefaultCredentials
        {
            set
            {
                this.m_smtpClient.UseDefaultCredentials = value;
            }
        }
        public NetworkCredential Credential
        {
            set
            {
                this.m_smtpClient.Credentials = value;
            }
        }
        public bool EnableSSL
        {
            set
            {
                this.m_smtpClient.EnableSsl = value;
            }
        }
        public int Port
        {
            set
            {
                this.m_smtpClient.Port = value;
            }
        }





        /// <summary>
        /// 寄出 MailMessage
        /// </summary>
        public void Send()
        {
            try
            {
                //MailAddress from = new MailAddress("ben@contoso.com");
                //MailAddress to = new MailAddress("Jane@contoso.com");


                //MailMessage message = new MailMessage(from, to);
                //message.Subject = "Using the SmtpClient class.";
                //message.Body = @"Using this feature, you can send an e-mail message from an application very easily.";
                //Attachment data = new Attachment(file);

                // Add time stamp information for the file.
                //ContentDisposition disposition = data.ContentDisposition;
                //disposition.CreationDate = System.IO.File.GetCreationTime(file);
                //disposition.ModificationDate = System.IO.File.GetLastWriteTime(file);
                //disposition.ReadDate = System.IO.File.GetLastAccessTime(file);
                // Add the file attachment to this e-mail message.
                //message.Attachments.Add(data);


                m_smtpClient.Send(this.m_mailMessage);



            }
            catch
            {
                throw;
            }
        }


        public void Send(string from, string to, string cc, string bcc, string body, string subject)
        {
            this.From = from;
            this.To = to;
            this.CC = cc;
            this.Body = body;
            this.Subject = subject;
            this.Send();
        }

    }
}

